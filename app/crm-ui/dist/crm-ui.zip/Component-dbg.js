sap.ui.define(["sap/fe/core/AppComponent"], function (BaseComponent) {
  "use strict";

  /**
   * @namespace crm.crmui
   */
  const Component = BaseComponent.extend("crm.crmui.Component", {
    metadata: {
      manifest: "json"
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
